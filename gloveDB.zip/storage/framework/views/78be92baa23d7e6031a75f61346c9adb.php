<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Laravel</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

       
    </head>
    <body >
        <div style= "display:flex">
            <form method="POST" action="<?php echo e(route('register.store')); ?>" >
                 <?php echo csrf_field(); ?>
                <h1>Crear cuenta</h1>
                <input type="email" name="email" placeholder="Correo electronico" required>
                <input type="password" name="password" placeholder="Contraseña" required>
                <input type="password" name="password_confirmation" placeholder="Confirmar contraseña">
                <button type="submit">Registrate</button>

            </form>
            <?php if(session('success')): ?>
    <div style="color: green"><?php echo e(session('success')); ?></div>
<?php endif; ?>

        </div>
        
    </body>
</html><?php /**PATH C:\laragon\www\GLOVEtest\resources\views/register.blade.php ENDPATH**/ ?>