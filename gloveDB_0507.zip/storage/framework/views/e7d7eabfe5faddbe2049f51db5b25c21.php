<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Logueado</title>
</head>
<body>
    <?php if(session('success')): ?>
        <h2 style="color: green; text-align: center;"><?php echo e(session('success')); ?></h2>
    <?php endif; ?>

    <p style="text-align: center;">Bienvenido a GLOVE.</p>
</body>
</html>
<?php /**PATH C:\laragon\www\GLOVEtest\resources\views/login-success.blade.php ENDPATH**/ ?>